
## Unreleased (2025-11-08)

#### :rocket: Enhancement
* [#60](https://github.com/frederic34/dolibarr_module_tuicalendar/pull/60) add translator ([@frederic34](https://github.com/frederic34))

#### :bug: Bug Fix
* [#47](https://github.com/frederic34/dolibarr_module_tuicalendar/pull/47) delete deleted events ([@frederic34](https://github.com/frederic34))

#### Committers: 2
- Bailly Benjamin ([@BenjaminDev34](https://github.com/BenjaminDev34))
- Frédéric FRANCE ([@frederic34](https://github.com/frederic34))
